<?php
error_reporting(0);
session_start();
include('net.php');
$error = array();

if (isset($_GET['logout'])) {
    unset($_SESSION['user']);
}
if (isset($_SESSION['user'])) {
    header("location: admin.php");
}


if (isset($_POST['Submit'])) {

    if (empty($_POST['id'])) {
        $error[] = "id IS NOT EMPTY" . "<br>";
    }

    if (empty($_POST['pwd'])) {
        $error[] = "PASSWORD IS NOT EMPTY" . "<br>";
    }

    if (empty($error)) {
//        $date=date('Y-m-d h:s:i');
//        var_dump($date);
//        die();
        $data = $db->select('log_in', '*', array('id' => $_POST['id'], 'password' => $_POST['pwd']));
      //  var_dump($data[0]['role']) . "<br>";

    }
    if (empty($data)) {
        $error[] = "invalid  id or password";
    } else {

        if ($data[0]['role'] == 'superadmin') {


                $_SESSION['user'] = $data[0];
                header('location:admin.php');
            }
        if ($data[0]['role'] == 'admin') {
            $_SESSION['user'] = $data[0];
            header('location:dashboard.php');
        }
        if ($data[0]['role'] == 'user') {
            $_SESSION['user'] = $data[0];
            header("location: employee.php");
        }
    }

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Welcome admin</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!--===============================================================================================-->
    <link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="fonts/Linearicons-Free-v1.0.0/icon-font.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="css/util.css">
    <link rel="stylesheet" type="text/css" href="css/main.css">
    <!--===============================================================================================-->
</head>
<body>
<div class="limiter">
    <div class="container-login100">
        <div class="wrap-login100 p-b-160 p-t-50">
            <form class="login100-form validate-form" method="post">
                <?php
                foreach ($error as $err) {
                    echo $err;
                }
                ?>
                <span class="login100-form-title p-b-43">
						Account Login
					</span>

                <div class="wrap-input100 rs1 validate-input" data-validate="Username is required">
                    <input class="input100" type="text" name="id">
                    <span class="label-input100">Username</span>
                </div>


                <div class="wrap-input100 rs2 validate-input" data-validate="Password is required">
                    <input class="input100" type="password" name="pwd">
                    <span class="label-input100">Password</span>
                </div>

                <div class="container-login100-form-btn">
                    <button class="login100-form-btn" name="Submit" type="Submit">
                        Sign in
                    </button>
                </div>

                <div class="text-center w-full p-t-23">
                    <a href="#" class="txt1">
                        Forgot password?
                    </a>
                </div>
            </form>
        </div>
    </div>
</div>


<!--===============================================================================================-->
<script src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
<script src="vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
<script src="vendor/bootstrap/js/popper.js"></script>
<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
<script src="vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
<script src="vendor/daterangepicker/moment.min.js"></script>
<script src="vendor/daterangepicker/daterangepicker.js"></script>
<!--===============================================================================================-->
<script src="vendor/countdowntime/countdowntime.js"></script>
<!--===============================================================================================-->
<script src="js/main.js"></script>

</body>
</html>

