<?php

include 'Medoo.php';
$db=new Medoo\Medoo(array(
    'database_type' => 'mysql',
    'database_name' => 'project',
    'server' => 'localhost',
    'username' => 'root',
    'password' => '',
));




?>